-- Execute apos 01. Somente leitura. Espera tabelas originais no schema public.
-- Cada consulta deve retornar zero linhas ou zero inconsistencias.
WITH referencias AS (
 SELECT 'empresa' AS tipo,p.process_id AS registro FROM qai_innovation_v2.innovation_processes p
 LEFT JOIN public.companies c ON c.company_id::text=p.company_id WHERE c.company_id IS NULL
 UNION ALL
 SELECT 'departamento_empresa',p.process_id FROM qai_innovation_v2.innovation_processes p
 LEFT JOIN public.departments d ON d.department_id::text=p.department_id AND d.company_id::text=p.company_id WHERE d.department_id IS NULL
 UNION ALL
 SELECT 'executor_processo',t.task_id FROM qai_innovation_v2.innovation_tasks t
 JOIN qai_innovation_v2.innovation_processes p ON p.process_id=t.process_id
 LEFT JOIN public.employees e ON e.employee_id::text=t.employee_id AND e.department_id::text=p.department_id AND e.company_id::text=p.company_id WHERE e.employee_id IS NULL
 UNION ALL
 SELECT 'log_executor_data',x.task_id FROM qai_innovation_v2.innovation_task_usage x
 JOIN qai_innovation_v2.innovation_tasks t ON t.task_id=x.task_id
 LEFT JOIN public.ai_usage_logs l ON l.usage_id::text=x.usage_id AND l.employee_id::text=t.employee_id AND l.timestamp::timestamp BETWEEN t.started_at AND t.completed_at WHERE l.usage_id IS NULL
 UNION ALL
 SELECT 'projeto_empresa',t.task_id FROM qai_innovation_v2.innovation_tasks t
 JOIN qai_innovation_v2.innovation_processes p ON p.process_id=t.process_id
 LEFT JOIN public.projects j ON j.project_id::text=t.project_id AND j.company_id::text=p.company_id WHERE t.project_id IS NOT NULL AND j.project_id IS NULL
 UNION ALL
 SELECT 'equipe_integrante',m.employee_id FROM qai_innovation_v2.innovation_team_memberships m
 JOIN qai_innovation_v2.innovation_teams t ON t.team_id=m.team_id
 LEFT JOIN public.employees e ON e.employee_id::text=m.employee_id AND e.department_id::text=t.department_id AND e.company_id::text=t.company_id WHERE e.employee_id IS NULL
 UNION ALL
 SELECT 'revisor',r.review_id FROM qai_innovation_v2.innovation_reviews r
 JOIN qai_innovation_v2.innovation_tasks t ON t.task_id=r.task_id
 JOIN qai_innovation_v2.innovation_processes p ON p.process_id=t.process_id
 LEFT JOIN public.employees e ON e.employee_id::text=r.reviewer_employee_id AND e.department_id::text=p.department_id
 WHERE r.review_state='Realizada' AND (e.employee_id IS NULL OR r.reviewer_employee_id=t.employee_id OR r.reviewed_at<t.completed_at)
 UNION ALL
 SELECT 'responsavel_acao',a.action_id FROM qai_innovation_v2.innovation_management_actions a
 JOIN qai_innovation_v2.innovation_alerts l ON l.alert_id=a.alert_id
 JOIN qai_innovation_v2.innovation_risk_scores s ON s.score_id=l.score_id
 LEFT JOIN public.employees e ON e.employee_id::text=a.owner_employee_id AND e.department_id::text=s.department_id AND e.company_id::text=s.company_id WHERE e.employee_id IS NULL
 UNION ALL
 SELECT 'avaliador_feedback',f.feedback_id FROM qai_innovation_v2.innovation_manager_feedback f
 JOIN qai_innovation_v2.innovation_risk_scores s ON s.score_id=f.score_id
 LEFT JOIN public.employees e ON e.employee_id::text=f.reviewer_employee_id AND e.department_id::text=s.department_id WHERE e.employee_id IS NULL
)
SELECT tipo, count(*) AS inconsistencias FROM referencias GROUP BY tipo;

-- Recalculo independente do score armazenado: retorno deve ser vazio.
WITH calc AS (
 SELECT score_id,sum(weight*component_score)/NULLIF(sum(weight),0) AS componente_base,
 sum(weight) AS cobertura
 FROM qai_innovation_v2.innovation_score_components WHERE available=1 GROUP BY score_id
)
SELECT s.score_id,s.final_score,round(c.componente_base*(0.5+0.5*s.intensity_percentile),2) AS recalculado
FROM qai_innovation_v2.innovation_risk_scores s JOIN calc c ON c.score_id=s.score_id
WHERE s.final_score IS NOT NULL AND abs(s.final_score-round(c.componente_base*(0.5+0.5*s.intensity_percentile),2))>0.01;

-- Disponibilidade de evidencias: retorno deve ser vazio.
SELECT score_id FROM qai_innovation_v2.innovation_risk_scores
WHERE final_score IS NOT NULL AND (ai_task_count<20 OR evidence_coverage<0.60);

-- Temporalidade de alertas, acoes e feedback: retorno deve ser vazio.
SELECT a.action_id FROM qai_innovation_v2.innovation_management_actions a
JOIN qai_innovation_v2.innovation_alerts l ON l.alert_id=a.alert_id
WHERE a.created_at<l.created_at OR a.completed_at>l.closed_at;

-- Contagens informativas: comparar com validacao.json.
SELECT scope_type,risk_level,count(*) FROM qai_innovation_v2.innovation_risk_scores
GROUP BY scope_type,risk_level ORDER BY scope_type,risk_level;
