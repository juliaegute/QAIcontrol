"""Gera pacote PostgreSQL aditivo. Usa somente bibliotecas padrão Python.
python complementar_postgresql.py base_original.zip complemento_anterior.zip pasta_nova
"""
import calendar, csv, hashlib, io, json, random, re, shutil, sqlite3, sys, tempfile, zipfile
from collections import defaultdict, Counter
from datetime import datetime, date, timedelta
from pathlib import Path

base,previous,out=map(Path,sys.argv[1:4]); out.mkdir(exist_ok=False,parents=True)
hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [base,previous]}
z=zipfile.ZipFile(base); prior=zipfile.ZipFile(previous)
def read(name):
    return list(csv.DictReader(io.StringIO(z.read(next(n for n in z.namelist() if n.endswith('/csv/'+name+'.csv'))).decode('utf-8-sig'))))
employees={x['employee_id']:x for x in read('employees')}; departments={x['department_id']:x for x in read('departments')}
logs=read('ai_usage_logs'); logmap={x['usage_id']:x for x in logs}
training=read('training_records'); approvals={(x['company_id'],x['ai_tool_id']):x for x in read('approved_ai_tools')}
security=read('security_events'); projects={x['project_id']:x for x in read('projects')}
temp=Path(tempfile.mkdtemp(prefix='qai_pg_build_')); db=sqlite3.connect(temp/'verification.sqlite'); db.row_factory=sqlite3.Row
# Restaura registros do SQL íntegro, ignorando SQLite/journal incompleto do pacote antigo.
db.executescript(prior.read('importar_sqlite.sql').decode()); db.execute('PRAGMA foreign_keys=ON')
old_order=['innovation_processes','innovation_tasks','innovation_task_usage','innovation_reviews','innovation_manual_assessments']
old_records={t:[tuple(x) for x in db.execute('SELECT * FROM '+t)] for t in old_order}
schema='''
CREATE TABLE innovation_teams(team_id TEXT PRIMARY KEY,company_id TEXT NOT NULL,department_id TEXT NOT NULL,team_name TEXT NOT NULL,is_synthetic INTEGER NOT NULL CHECK(is_synthetic=1));
CREATE TABLE innovation_team_memberships(employee_id TEXT PRIMARY KEY,team_id TEXT NOT NULL REFERENCES innovation_teams,valid_from DATE NOT NULL,valid_to DATE,is_synthetic INTEGER NOT NULL CHECK(is_synthetic=1),CHECK(valid_to IS NULL OR valid_to>=valid_from));
CREATE TABLE innovation_score_versions(version_id TEXT PRIMARY KEY,version_name TEXT NOT NULL,definition TEXT NOT NULL,minimum_tasks INTEGER NOT NULL,minimum_coverage NUMERIC NOT NULL,created_at TIMESTAMP NOT NULL,is_synthetic INTEGER NOT NULL CHECK(is_synthetic=1));
CREATE TABLE innovation_risk_scores(score_id TEXT PRIMARY KEY,version_id TEXT NOT NULL REFERENCES innovation_score_versions,company_id TEXT NOT NULL,department_id TEXT NOT NULL,team_id TEXT REFERENCES innovation_teams,process_id TEXT REFERENCES innovation_processes,scope_type TEXT NOT NULL CHECK(scope_type IN('department','team','process')),period_start DATE NOT NULL,period_end DATE NOT NULL,task_count INTEGER NOT NULL,ai_task_count INTEGER NOT NULL,request_count INTEGER NOT NULL,observed_users INTEGER NOT NULL,intensity_percentile NUMERIC NOT NULL CHECK(intensity_percentile BETWEEN 0 AND 1),evidence_coverage NUMERIC NOT NULL CHECK(evidence_coverage BETWEEN 0 AND 1),final_score NUMERIC CHECK(final_score BETWEEN 0 AND 100),risk_level TEXT NOT NULL CHECK(risk_level IN('Baixo','Moderado','Alto','Critico','Dados insuficientes')),calculated_at TIMESTAMP NOT NULL,is_synthetic INTEGER NOT NULL CHECK(is_synthetic=1),CHECK(period_end>=period_start),CHECK((scope_type='department' AND team_id IS NULL AND process_id IS NULL) OR (scope_type='team' AND team_id IS NOT NULL AND process_id IS NULL) OR (scope_type='process' AND process_id IS NOT NULL AND team_id IS NULL)),CHECK((final_score IS NULL AND risk_level='Dados insuficientes') OR (final_score IS NOT NULL AND risk_level!='Dados insuficientes')));
CREATE UNIQUE INDEX innovation_score_grain ON innovation_risk_scores(version_id,scope_type,department_id,coalesce(team_id,''),coalesce(process_id,''),period_start);
CREATE TABLE innovation_score_components(score_id TEXT NOT NULL REFERENCES innovation_risk_scores,component TEXT NOT NULL,numerator INTEGER NOT NULL CHECK(numerator>=0),denominator INTEGER NOT NULL CHECK(denominator>=numerator),weight NUMERIC NOT NULL CHECK(weight>0 AND weight<=1),component_score NUMERIC CHECK(component_score BETWEEN 0 AND 100),available INTEGER NOT NULL CHECK(available IN(0,1)),source_definition TEXT NOT NULL,is_synthetic INTEGER NOT NULL CHECK(is_synthetic=1),PRIMARY KEY(score_id,component));
CREATE TABLE innovation_alerts(alert_id TEXT PRIMARY KEY,score_id TEXT NOT NULL UNIQUE REFERENCES innovation_risk_scores,created_at TIMESTAMP NOT NULL,severity TEXT NOT NULL,reason TEXT NOT NULL,status TEXT NOT NULL CHECK(status IN('Aberto','Em acompanhamento','Encerrado')),closed_at TIMESTAMP,is_synthetic INTEGER NOT NULL CHECK(is_synthetic=1),CHECK(closed_at IS NULL OR closed_at>=created_at),CHECK((status='Encerrado' AND closed_at IS NOT NULL) OR (status!='Encerrado' AND closed_at IS NULL)));
CREATE TABLE innovation_management_actions(action_id TEXT PRIMARY KEY,alert_id TEXT NOT NULL REFERENCES innovation_alerts,owner_employee_id TEXT NOT NULL,action_type TEXT NOT NULL,created_at TIMESTAMP NOT NULL,due_at TIMESTAMP NOT NULL,status TEXT NOT NULL CHECK(status IN('Planejada','Em andamento','Concluida')),completed_at TIMESTAMP,outcome_note TEXT,is_synthetic INTEGER NOT NULL CHECK(is_synthetic=1),CHECK(due_at>=created_at),CHECK(completed_at IS NULL OR completed_at>=created_at),CHECK((status='Concluida' AND completed_at IS NOT NULL) OR (status!='Concluida' AND completed_at IS NULL)));
CREATE TABLE innovation_manager_feedback(feedback_id TEXT PRIMARY KEY,score_id TEXT NOT NULL REFERENCES innovation_risk_scores,reviewer_employee_id TEXT NOT NULL,submitted_at TIMESTAMP NOT NULL,clarity_rating INTEGER NOT NULL CHECK(clarity_rating BETWEEN 1 AND 5),usefulness_rating INTEGER NOT NULL CHECK(usefulness_rating BETWEEN 1 AND 5),decision_support_rating INTEGER NOT NULL CHECK(decision_support_rating BETWEEN 1 AND 5),agrees_with_classification INTEGER NOT NULL CHECK(agrees_with_classification IN(0,1)),comment TEXT NOT NULL,evidence_type TEXT NOT NULL CHECK(evidence_type='Feedback simulado; nao coletado da QSOFT'),is_synthetic INTEGER NOT NULL CHECK(is_synthetic=1));
'''
db.executescript(schema)
new_order=['innovation_teams','innovation_team_memberships','innovation_score_versions','innovation_risk_scores','innovation_score_components','innovation_alerts','innovation_management_actions','innovation_manager_feedback']
def put(t,values): db.execute('INSERT INTO '+t+' VALUES('+','.join('?' for _ in values)+')',values)
r=random.Random(20260918); members=defaultdict(list); teamof={}
for e in employees.values(): members[e['department_id']].append(e)
for did,es in sorted(members.items()):
    es=sorted(es,key=lambda e:(e['job_role'],e['employee_id']))
    for k in range(0,len(es),12):
        team=f'INEQ-{did}-{k//12+1:02d}'
        put('innovation_teams',(team,departments[did]['company_id'],did,f"{departments[did]['department_name']} - equipe {k//12+1}",1))
        for e in es[k:k+12]:
            teamof[e['employee_id']]=team
            put('innovation_team_memberships',(e['employee_id'],team,e['hire_date'],None,1))
definition={
 'purpose':'Indice demonstrativo de sinais de risco, nao diagnostico',
 'weights':{'supervisao':.30,'qualidade':.20,'capacitacao':.15,'governanca':.15,'autonomia':.20},
 'formula':'weighted_mean_available_components * (0.5 + 0.5 * intensity_percentile)',
 'intensity':'percentil medio (rank-0.5)/N de requisicoes por usuario observado, entre unidades do mesmo escopo e mes; N=1 usa 0.5',
 'minimum_tasks':20,'minimum_coverage':.60,
 'component_min_denominators':{'supervisao':5,'qualidade':5,'capacitacao':5,'governanca':5,'autonomia':3},
 'bands':{'Baixo':'[0,35)','Moderado':'[35,55)','Alto':'[55,75)','Critico':'[75,100]'},
 'alerts':'apenas departamento, final_score >=35; >=55 alta prioridade; abaixo disso acompanhamento moderado',
 'warning':'Regras e cortes arbitrarios para demonstracao. Nao sao metodologia validada nem percentuais de probabilidade.'}
put('innovation_score_versions',('demo-v1','Demonstracao explicavel v1',json.dumps(definition,ensure_ascii=False),20,.60,'2026-09-17 00:00:00',1))
reviews={x['task_id']:dict(x) for x in db.execute('SELECT * FROM innovation_reviews')}
assessments=defaultdict(list)
for a in db.execute('SELECT * FROM innovation_manual_assessments'): assessments[(a['employee_id'],a['assessment_date'][:7])].append(dict(a))
training_by=defaultdict(list)
for x in training:
    if x['completion_status']=='Concluido' and x['completion_date']: training_by[x['employee_id']].append(x['completion_date'])
groups={}
def group(scope,unit,month,did):
    key=(scope,unit,month)
    if key not in groups: groups[key]={'scope':scope,'unit':unit,'month':month,'did':did,'tasks':[],'logs':[]}
    return groups[key]
tasks={x['task_id']:dict(x) for x in db.execute('SELECT * FROM innovation_tasks')}
for t in tasks.values():
    e=employees[t['employee_id']]; month=t['started_at'][:7]; did=e['department_id']
    for scope,unit in [('department',did),('team',teamof[e['employee_id']]),('process',t['process_id'])]: group(scope,unit,month,did)['tasks'].append(t)
for l in logs:
    e=employees[l['employee_id']]; did=e['department_id']; month=l['timestamp'][:7]
    for scope,unit in [('department',did),('team',teamof[e['employee_id']])]: group(scope,unit,month,did)['logs'].append(l)
for x in db.execute('SELECT * FROM innovation_task_usage'):
    t=tasks[x['task_id']]; l=logmap[x['usage_id']]
    group('process',t['process_id'],t['started_at'][:7],employees[t['employee_id']]['department_id'])['logs'].append(l)
rankgroups=defaultdict(list)
for g in groups.values():
    g['users']={l['employee_id'] for l in g['logs']}; g['requests']=sum(int(l['request_count']) for l in g['logs'])
    g['rate']=g['requests']/max(1,len(g['users'])); rankgroups[(g['scope'],g['month'])].append(g)
for gs in rankgroups.values():
    rates=sorted(g['rate'] for g in gs)
    for g in gs:
        g['pct']=(sum(x<g['rate'] for x in rates)+.5*sum(x==g['rate'] for x in rates))/len(gs)
scores=[]
for n,(key,g) in enumerate(sorted(groups.items()),1):
    year,month=map(int,g['month'].split('-')); end=date(year,month,calendar.monthrange(year,month)[1]); cutoff=str(end)+' 23:59:59'; start=f'{g["month"]}-01'
    # Reconstrucao retrospectiva: dados/evidencias somente ate o fim do mes.
    ts=[t for t in g['tasks'] if t['completed_at']<=cutoff]; ai=[t for t in ts if t['used_ai']]
    rev=[reviews[t['task_id']] for t in ai if reviews[t['task_id']]['review_state']!='Desconhecida' and (reviews[t['task_id']]['reviewed_at'] is None or reviews[t['task_id']]['reviewed_at']<=cutoff)]
    users=g['users']; tests=[]
    for eid in users:
        tests.extend(a for a in assessments[(eid,g['month'])] if a['test_status']=='Realizado' and (g['scope']!='process' or a['process_id']==g['unit']))
    known=[]
    for l in g['logs']:
        ap=approvals.get((l['company_id'],l['ai_tool_id']))
        if ap and ap['approval_date']<=l['timestamp'][:10]: known.append(ap)
    nums={
      'supervisao':(sum(x['review_state']=='Nao realizada' for x in rev),len(rev),'Revisao nao realizada / revisoes conhecidas das tarefas com IA; desconhecidas e revisoes futuras excluidas'),
      'qualidade':(sum(t['outcome'] in ['Retrabalho','Rejeitada'] for t in ai),len(ai),'Tarefas com IA em retrabalho ou rejeitadas / tarefas com IA concluidas na janela'),
      'capacitacao':(sum(not any(d<=str(end) for d in training_by[e]) for e in users),len(users),'Usuarios observados sem curso concluido ate fim do mes / usuarios observados; sem registro nao prova ausencia real de capacitacao'),
      'governanca':(sum(x['approval_status']!='Aprovado' for x in known),len(known),'Logs com status bloqueado/em avaliacao / logs com decisao registrada ate o uso; nao avalia permissoes de departamento'),
      'autonomia':(sum(a['test_passed']==0 for a in tests),len(tests),'Testes manuais reprovados / testes realizados no mes; autorrelatos e nao testados excluidos')}
    comp=[]; weighted=coverage=0
    for name,(num,den,source) in nums.items():
        weight=definition['weights'][name]; available=int(den>=definition['component_min_denominators'][name]); val=100*num/den if available else None
        if available: coverage+=weight; weighted+=weight*val
        comp.append((name,num,den,weight,val,available,source))
    eligible=len(ai)>=20 and coverage>=.60-1e-9
    score=round(weighted/coverage*(.5+.5*g['pct']),2) if eligible else None
    level='Dados insuficientes' if score is None else 'Baixo' if score<35 else 'Moderado' if score<55 else 'Alto' if score<75 else 'Critico'
    sid=f'INS-{n:07d}'; calc='2026-09-17 00:00:00'
    put('innovation_risk_scores',(sid,'demo-v1',departments[g['did']]['company_id'],g['did'],g['unit'] if g['scope']=='team' else None,g['unit'] if g['scope']=='process' else None,g['scope'],start,str(end),len(ts),len(ai),g['requests'],len(users),g['pct'],round(coverage,6),score,level,calc,1))
    for name,num,den,weight,val,available,source in comp: put('innovation_score_components',(sid,name,num,den,weight,val,available,source,1))
    scores.append((sid,g,score,level,comp))
# Fluxo de demonstracao apos o calculo retrospectivo. Datas futuras sao cenario, nao eventos reais.
alerts=actions=feedback=0
for sid,g,score,level,comp in scores:
    if g['scope']!='department' or score is None or score<35: continue
    eligible=[e for e in members[g['did']] if e['hire_date']<='2026-09-17' and e['active'].lower() in ['true','1']]
    if not eligible: continue
    alerts+=1; aid=f'INAL-{alerts:06d}'; created=datetime(2026,9,18,9)+timedelta(minutes=alerts)
    selected=sorted([c for c in comp if c[5]],key=lambda c:c[3]*c[4],reverse=True)[0]
    reason=f'Cenario sintetico: risco {level}; maior contribuicao: {selected[0]}. Competencia {g["month"]}.'
    has_action=r.random()<.72; done=has_action and r.random()<.42
    closed=(created+timedelta(days=r.randint(8,28))) if done else None
    status='Encerrado' if done else 'Em acompanhamento' if has_action else 'Aberto'
    put('innovation_alerts',(aid,sid,str(created),'Alta' if score>=55 else 'Moderada',reason,status,str(closed) if closed else None,1))
    owner=r.choice(eligible)['employee_id']
    if has_action:
        actions+=1; at=created+timedelta(days=1); due=at+timedelta(days=14)
        kind={'supervisao':'Revisar procedimento de supervisao','qualidade':'Investigar retrabalho','capacitacao':'Planejar capacitacao','governanca':'Revisar politica de ferramentas','autonomia':'Testar alternativa manual'}[selected[0]]
        state='Concluida' if done else r.choice(['Planejada','Em andamento'])
        put('innovation_management_actions',(f'INAC-{actions:06d}',aid,owner,kind,str(at),str(due),state,str(closed-timedelta(hours=1)) if done else None,'Execucao simulada; efeito sobre risco nao medido' if done else None,1))
    if r.random()<.35:
        feedback+=1; agrees=int(r.random()<.65)
        put('innovation_manager_feedback',(f'INFB-{feedback:06d}',sid,owner,str(created+timedelta(days=3)),r.randint(2,5),r.randint(1,5),r.randint(1,5),agrees,'SIMULADO: componentes ajudam a priorizar revisao.' if agrees else 'SIMULADO: precisamos de mais evidencias antes de concordar com a classificacao.','Feedback simulado; nao coletado da QSOFT',1))
db.commit()
assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'; assert not db.execute('PRAGMA foreign_key_check').fetchall()
for t,rows in old_records.items(): assert [tuple(x) for x in db.execute('SELECT * FROM '+t)]==rows
for p,h in hashes.items(): assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
for t in tasks.values():
    assert t['employee_id'] in employees
    if t['project_id']: assert projects[t['project_id']]['company_id']==employees[t['employee_id']]['company_id']
for x in db.execute('SELECT * FROM innovation_reviews WHERE review_state=\'Realizada\''):
    assert x['reviewer_employee_id']!=tasks[x['task_id']]['employee_id']
    assert employees[x['reviewer_employee_id']]['department_id']==employees[tasks[x['task_id']]['employee_id']]['department_id']
for s in db.execute('SELECT * FROM innovation_risk_scores WHERE final_score IS NOT NULL'):
    cs=db.execute('SELECT * FROM innovation_score_components WHERE score_id=? AND available=1',(s['score_id'],)).fetchall()
    expected=round(sum(c['weight']*c['component_score'] for c in cs)/sum(c['weight'] for c in cs)*(.5+.5*s['intensity_percentile']),2)
    assert expected==s['final_score']
for a in db.execute('SELECT * FROM innovation_management_actions'):
    assert a['owner_employee_id'] in employees
    alert=db.execute('SELECT * FROM innovation_alerts WHERE alert_id=?',(a['alert_id'],)).fetchone()
    assert a['created_at']>=alert['created_at']
    if a['completed_at']: assert a['completed_at']<=alert['closed_at']
order=old_order+new_order
counts={t:db.execute('SELECT count(*) FROM '+t).fetchone()[0] for t in order}
report={'counts':counts,'original_inputs_sha256':hashes,'original_five_tables_preserved':True,'sqlite_integrity':'ok','internal_foreign_keys':'ok','score_recalculation':'ok','postgresql_execution':'not run: no PostgreSQL server available','risk_distribution':[dict(x) for x in db.execute('SELECT scope_type,risk_level,count(*) AS count FROM innovation_risk_scores GROUP BY scope_type,risk_level')],'seed':20260918}
(out/'validacao.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
(out/'formula_demo_v1.json').write_text(json.dumps(definition,ensure_ascii=False,indent=2))
# PostgreSQL: um schema novo, transacao unica, sem DROP/UPDATE/DELETE e sem IF NOT EXISTS.
lines=['-- QAI Control: complemento SINTETICO, exclusivamente aditivo.','BEGIN;','SET LOCAL standard_conforming_strings = on;','CREATE SCHEMA qai_innovation_v2;','SET LOCAL search_path TO qai_innovation_v2, pg_catalog;']
for t in order:
    ddl=db.execute('SELECT sql FROM sqlite_master WHERE type=\'table\' AND name=?',(t,)).fetchone()[0]
    # Datas legadas eram texto. Mantem valores, converte apenas os tipos no PostgreSQL.
    for col in ['started_at','completed_at','reviewed_at']:
        ddl=re.sub(r'\b'+col+r' TEXT\b',col+' TIMESTAMP',ddl)
    ddl=re.sub(r'\bassessment_date TEXT\b','assessment_date DATE',ddl)
    lines.append(ddl+';')
def literal(v):
    if v is None: return 'NULL'
    if isinstance(v,(int,float)): return str(v)
    return "'"+str(v).replace("'","''")+"'"
for t in order:
    rows=db.execute('SELECT * FROM '+t).fetchall()
    for i in range(0,len(rows),400):
        lines.append('INSERT INTO '+t+' VALUES\n'+',\n'.join('('+','.join(literal(v) for v in row)+')' for row in rows[i:i+400])+';')
for name,sql in db.execute('SELECT name,sql FROM sqlite_master WHERE type=\'index\' AND sql IS NOT NULL'): lines.append(sql+';')
lines+=['CREATE INDEX idx_innovation_tasks_employee_time ON innovation_tasks(employee_id,started_at);','CREATE INDEX idx_innovation_tasks_process_time ON innovation_tasks(process_id,started_at);','CREATE INDEX idx_innovation_scores_department_month ON innovation_risk_scores(department_id,period_start);','CREATE INDEX idx_innovation_scores_team_month ON innovation_risk_scores(team_id,period_start);','CREATE INDEX idx_innovation_alert_status ON innovation_alerts(status,created_at);']
lines.append('''CREATE VIEW innovation_dashboard_scores AS
SELECT s.*, v.version_name FROM innovation_risk_scores s
JOIN innovation_score_versions v ON v.version_id=s.version_id;
CREATE VIEW innovation_management_summary AS
SELECT s.company_id,s.department_id,s.period_start,
count(*) AS alerts_total,
count(*) FILTER (WHERE EXISTS (SELECT 1 FROM innovation_management_actions a WHERE a.alert_id=l.alert_id)) AS alerts_with_actions,
count(*) FILTER (WHERE l.status='Encerrado') AS alerts_closed
FROM innovation_alerts l JOIN innovation_risk_scores s ON s.score_id=l.score_id
GROUP BY s.company_id,s.department_id,s.period_start;''')
lines.append('COMMIT;')
(out/'01_importar_postgresql.sql').write_text('\n'.join(lines),encoding='utf-8')
shutil.copy2(__file__,out/'complementar_postgresql.py')
shutil.copy2(Path(__file__).with_name('README_postgresql.md'),out/'LEIA-ME.md')
shutil.copy2(Path(__file__).with_name('README_postgresql.md'),out/'README_postgresql.md')
shutil.copy2(Path(__file__).with_name('validar_vinculos_postgresql.sql'),out/'02_validar_vinculos.sql')
shutil.copy2(Path(__file__).with_name('validar_vinculos_postgresql.sql'),out/'validar_vinculos_postgresql.sql')
(out/'dicionario_complemento_anterior.md').write_bytes(prior.read('LEIA-ME.md'))
db.close()
shutil.make_archive(str(out.parent/'QAI_Control_Inovacao_PostgreSQL'),'zip',out)
print(json.dumps(report,ensure_ascii=False,indent=2))
