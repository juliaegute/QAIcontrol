# QAI Control — complemento sintético para a inovação

## O que foi entregue

Dados inteiramente sintéticos para demonstrar sinais de risco de dependência de IA. Não representam pessoas, observações reais nem evidência científica. Os padrões são hipóteses de simulação plausíveis, não distribuições empiricamente calibradas.

Nenhuma tabela existente foi alterada. Este pacote contém SOMENTE cinco novas tabelas, prefixadas com `innovation_`, evitando colisões. Os IDs de empresa, departamento, colaborador, projeto e uso vêm da base original fornecida. O complemento também é compatível com a versão preenchida enquanto esses IDs forem preservados; ele não corrige nem substitui seus dados.

| Tabela | Linhas | Uma linha representa |
|---|---:|---|
| innovation_processes | 161 | Um processo genérico de apoio por departamento |
| innovation_tasks | 52.870 | Uma tarefa simulada, com ou sem IA |
| innovation_task_usage | 39.204 | Vínculo entre uma tarefa e um log existente |
| innovation_reviews | 39.204 | Estado da revisão de uma tarefa com IA |
| innovation_manual_assessments | 10.037 | Uma avaliação por colaborador/processo/mês amostrado |

## Arquivos e utilização

- `qai_inovacao_complemento.sqlite`: banco complementar pronto para consulta em SQLite.
- `importar_sqlite.sql`: criação e inserção somente das novas tabelas. Dialeto SQLite, não executar diretamente em MySQL/PostgreSQL sem adaptação dos tipos e regras.
- `gerar_complemento.py`: gerador reprodutível, apenas biblioteca padrão Python. Execute `python gerar_complemento.py synthetic_ai_usage_dataset.zip pasta_nova`. A pasta de saída deve não existir.
- `validacao.json`: contagens, hash da base e verificações.

Para consultar junto da base original sem modificá-la, abra o SQLite original e use `ATTACH DATABASE 'qai_inovacao_complemento.sqlite' AS inovacao;`. As novas tabelas ficam em `inovacao`. Não há senhas ou credenciais no pacote.

Exemplo de vínculo:

```sql
SELECT t.task_id, u.company_id, u.department_id, u.ai_tool_id,
       t.ai_participation, r.review_state
FROM inovacao.innovation_tasks t
JOIN inovacao.innovation_task_usage x ON x.task_id=t.task_id
JOIN ai_usage_logs u ON u.usage_id=x.usage_id
JOIN inovacao.innovation_reviews r ON r.task_id=t.task_id;
```

## Dicionário dos campos

Todos os registros têm `is_synthetic=1`. IDs novos não substituem IDs existentes. Booleanos usam 0/1; NULL significa desconhecido ou não aplicável. Datas/horas não possuem fuso, seguindo a base de origem.

### innovation_processes

- `process_id`: chave primária nova.
- `company_id`, `department_id`: vínculos com cadastros existentes.
- `process_name`: nome contextualizado ao departamento; processo genérico de apoio, não mapeamento real de processos.
- `criticality`: Alta para áreas financeiras, jurídicas, risco, operações bancárias, produção e manutenção; Media nas demais. Regra de demonstração, ajustável.
- `manual_fallback_documented`: existência simulada de procedimento alternativo manual; não prova competência individual.

### innovation_tasks

- `task_id`: chave primária; `process_id`: chave estrangeira interna.
- `employee_id`: executor da base; `project_id`: preservado do log, nulo quando não aplicável.
- `started_at`, `completed_at`: janela simulada; conclusão posterior ao início. Um log vinculado ocorre dentro dela.
- `task_type`: revisão técnica, comunicação, resposta ao cliente ou análise do departamento.
- `used_ai`: 1 com IA, 0 manual.
- `ai_participation`: Apoio, Parcial, Principal ou Sem IA. Não se simulou autonomia total sem evidência.
- `actual_duration_minutes`: duração SIMULADA observada no cenário, não latência de API.
- `estimated_manual_minutes`: estimativa SIMULADA; não contrafactual medido. Pode ser menor que o tempo com IA.
- `estimate_source`: explicita a natureza da estimativa.
- `outcome`: Concluida, Retrabalho ou Rejeitada; nunca interpretar todas as tarefas como sucesso.

### innovation_task_usage

- `task_id`: vínculo com tarefa; `usage_id`: log original único; chave composta task_id/usage_id.
- `purpose`: Revisar, Criar, Redigir ou Analisar.
- Ferramenta/modelo são obtidos pelo log; não são duplicados nesta tabela.

### innovation_reviews

- `review_id`: chave primária; `task_id`: uma revisão consolidada por tarefa com IA.
- `review_state`: Realizada, Nao realizada ou Desconhecida. Desconhecida não equivale a ausência de revisão.
- `reviewer_employee_id`: outro colaborador do mesmo departamento, contratado até a data da revisão.
- `reviewed_at`: posterior à conclusão da tarefa.
- `accepted_without_changes`: 1 apenas quando aprovado sem correções; 0 em correção/rejeição; NULL sem revisão conhecida.
- `correction_count`: inteiro; zero para aprovação sem alteração; NULL quando não se sabe.
- `review_minutes`: duração positiva, NULL sem revisão realizada.
- `review_result`: Aprovado, Corrigido ou Rejeitado; NULL sem revisão realizada.

### innovation_manual_assessments

- `assessment_id`: chave primária; `employee_id`, `process_id`: pessoa e processo.
- `assessment_date`: data do cenário; autorrelato não necessariamente aplicável a todas as tarefas históricas.
- `self_report_ability`: Sim, Com dificuldade ou Nao — percepção simulada.
- `test_status`: Realizado ou Nao testado.
- `test_score`: inteiro 0–100 somente com teste; não é score de dependência.
- `test_duration_minutes`: duração do teste simulado.
- `test_passed`: 1 se nota >=70, 0 caso contrário; limiar demonstrativo, não validado.
- `evidence_type`: Teste simulado ou Autorrelato simulado. Mesmo o teste NÃO é evidência real.

## Lógica e limitações da simulação

Seed fixa 20260917. Perfis individuais latentes de familiaridade com IA e habilidade manual foram sorteados separadamente: não há regra de que quem usa mais tem menor capacidade. Departamentos têm propensões diferentes de revisão. Há ruído nos testes e variação no tempo, incluindo retrabalho e tarefas nas quais IA não economiza tempo.

Foi selecionado no máximo um log por pessoa/dia, com probabilidade de seleção de 16% em cada evento até selecionar o primeiro. Logo, pessoas com mais eventos têm maior chance de aparecer. Não é amostra aleatória uniforme de colaboradores nem de tarefas. O vínculo tarefa/log é SIMULADO, não inferido a partir de conteúdo de prompt. Não implica que o log inteiro, que pode agregar requisições, corresponde a uma tarefa real identificada.

Tarefas manuais adicionais são geradas em aproximadamente 35% dos dias selecionados. Essa proporção é artificial e NÃO permite estimar a adoção real ou a fração real de trabalho com IA. A base não é controle de jornada; janelas podem se sobrepor e não devem fundamentar produtividade por hora trabalhada. Conclusão/revisão pode avançar algumas horas além do último dia dos logs.

Não foram inventados prompts, respostas, dados pessoais, fluxos entre departamentos ou autorizações reais. Os processos são genéricos e não têm histórico de alteração. Status atual do funcionário/licença não prova seu status histórico. As chaves externas para a base são validadas por correspondência; o banco complementar isolado não pode impor foreign keys SQLite entre bancos anexados.

## Como usar na inovação

- Heatmap: departamento/processo por período, exibindo participação Principal, revisão não realizada e resultados dos testes, com quantidade de observações.
- Grafo: departamento → processo → ferramenta, com arestas baseadas nos vínculos de uso. Não representar fluxo real de trabalho entre equipes sem dados para isso.
- Revisão: Nao realizada / (Realizada + Nao realizada); divulgar Desconhecida à parte.
- Capacidade manual: testes reprovados / testes realizados. Não contar Nao testado como incapacidade.
- Concentração por ferramenta: participação dos vínculos amostrados por ferramenta; não porcentagem do universo de tarefas.
- Recomendações demonstrativas: ampliar revisão de processos críticos, oferecer capacitação e testar procedimentos alternativos.

Não foi criada tabela de scores prontos: os pesos e limites sugeridos na conversa não foram validados. Calcular índices em camada separada, com versão da fórmula, período, cobertura e componentes. Usar estes mocks para testar interface e lógica, não para provar eficácia científica de um modelo. Treinar e testar apenas nestes dados mede principalmente as regras do gerador.

## Validação

Integridade SQLite, chaves internas, unicidade, vínculo executor/log, log dentro da janela da tarefa, ausência de valores inventados para revisões desconhecidas e hash do ZIP original foram verificados. O hash confirma que o arquivo de origem não foi modificado. As quantidades estão em validacao.json.
