# QAI Control — inovação para PostgreSQL

## Entrega e limites

Pacote complementar para implementar e demonstrar o Mapa Inteligente de Risco de Dependência de IA. Contém as cinco tabelas anteriores, com todos os registros preservados, e oito tabelas novas. Não contém cópia das 17 tabelas originais e não modifica nenhuma delas.

Os dados são SINTÉTICOS. Avaliações de gestores, ações de gestão e testes são cenários de demonstração, não validação real da QSOFT. O banco é suficiente para implementar o fluxo demonstrativo; validar a hipótese exige coleta e feedback reais. Não usar para decisões sobre trabalhadores reais.

## Importação no pgAdmin

1. Faça backup do banco atual. Teste primeiro em uma cópia de desenvolvimento.
2. No banco desejado, abra o Query Tool.
3. Abra `01_importar_postgresql.sql` e execute o arquivo inteiro. Ele pode levar alguns minutos.
4. Atualize Schemas. As tabelas ficarão em `qai_innovation_v2`, separadas de `public`.
5. Execute `02_validar_vinculos.sql` depois da importação. O script presume que as tabelas originais estão em `public`. Se estiverem em outro schema, ajuste apenas esse nome no script de validação e nas consultas de integração.

O script 01 é SQL PostgreSQL normal, com INSERTs, sem comandos exclusivos do psql ou caminhos de arquivos no servidor. Está em uma transação e não usa DROP, DELETE, UPDATE ou sobrescrita. Se `qai_innovation_v2` já existir, a importação para com erro: não apague o schema para tentar novamente sem antes verificar o que existe. Após erro no Query Tool, execute ROLLBACK antes de continuar. O pacote não foi aplicado ao seu servidor.

Não é necessário importar o SQLite anterior. Se você já tiver aquelas cinco tabelas em outro schema, elas serão copiadas intactas no novo schema; não serão atualizadas no lugar. A aplicação deve apontar para um único conjunto, evitando somar as duas cópias.

## Preservação e correção de empacotamento

O SQLite anterior foi entregue com um journal pendente, o que poderia fazê-lo abrir sem os registros. Neste pacote, os registros foram recuperados a partir do SQL completo anterior. As cinco tabelas tiveram conteúdo comparado linha por linha. Nada foi regenerado ou alterado nelas; os hashes dos ZIPs de entrada também permaneceram iguais.

## Tabelas existentes preservadas

| Tabela | Finalidade |
|---|---|
| innovation_processes | Processo genérico por departamento, criticidade e alternativa manual |
| innovation_tasks | Tarefas com/sem IA e resultado |
| innovation_task_usage | Vínculo da tarefa com usage_id original |
| innovation_reviews | Supervisão, correções e ausência de informação |
| innovation_manual_assessments | Autorrelato e testes sem IA |

O arquivo `dicionario_complemento_anterior.md` documenta os campos originais. Suas instruções de SQLite são históricas: para esta entrega prevalecem estas instruções PostgreSQL. Foram mantidos os booleanos 0/1 para preservar os dados. Datas novas usam DATE/TIMESTAMP; datas legadas foram tipadas sem mudar seus valores. Não foi inferido fuso ausente na fonte.

## Tabelas novas: dicionário

Todos os registros têm `is_synthetic=1`.

### innovation_teams

`team_id` (PK), `company_id`, `department_id`, `team_name`. Equipes sintéticas de até 12 integrantes dentro de cada departamento, agrupados por cargo/ID para reprodutibilidade. Não representam organograma real.

### innovation_team_memberships

`employee_id` (PK), `team_id` (FK), `valid_from` (contratação original), `valid_to` (NULL). Hipótese simplificadora: uma equipe estável por funcionário durante o histórico. O status atual inativo não permite inferir data de desligamento. Modelo não cobre transferências/recontratações; para isso, ampliar a chave para empregado/data inicial e impedir sobreposição de intervalos.

### innovation_score_versions

`version_id` (PK), `version_name`, `definition` (JSON serializado em TEXT com regras e pesos), `minimum_tasks`, `minimum_coverage`, `created_at`. Apenas demo-v1 foi criada. Alterações futuras devem usar novo ID, sem sobrescrever a versão histórica.

### innovation_risk_scores

`score_id` (PK), `version_id` (FK), `company_id`, `department_id`, `team_id` (FK opcional), `process_id` (FK opcional), `scope_type` (department/team/process), `period_start`, `period_end`, `task_count`, `ai_task_count`, `request_count`, `observed_users`, `intensity_percentile`, `evidence_coverage`, `final_score` (0–100 ou NULL), `risk_level`, `calculated_at`.

Uma linha por unidade/competência/versão. Departamentos, equipes e processos são visões alternativas dos mesmos dados: nunca somar os três escopos. O schema tem restrição de unicidade da competência e unidade. `calculated_at` é a data da reconstrução retrospectiva, não uma afirmação de que o score já existia no mês observado.

### innovation_score_components

`score_id` (FK), `component` (PK composta), `numerator`, `denominator`, `weight`, `component_score`, `available`, `source_definition`. Permite explicar e recalcular o resultado. Ausência de dados produz NULL, não zero. Cobertura é a soma dos pesos disponíveis, não confiança estatística.

### innovation_alerts

`alert_id` (PK), `score_id` (FK único), `created_at`, `severity`, `reason`, `status`, `closed_at`. Apenas scores departamentais >=35 geram alertas, evitando alertas duplicados de equipe/processo sobre o mesmo conjunto. Regra demonstrativa. Competência consta no motivo.

### innovation_management_actions

`action_id` (PK), `alert_id` (FK), `owner_employee_id`, `action_type`, `created_at`, `due_at`, `status`, `completed_at`, `outcome_note`. Responsável é um colaborador ativo da mesma área, não necessariamente gerente. Há alertas sem ação, ações planejadas, em andamento e concluídas. Conclusão não prova redução de risco; esse efeito não foi fabricado.

### innovation_manager_feedback

`feedback_id` (PK), `score_id` (FK), `reviewer_employee_id`, `submitted_at`, `clarity_rating`, `usefulness_rating`, `decision_support_rating` (1–5), `agrees_with_classification` (0/1), `comment`, `evidence_type`. Respostas incluem discordância e notas baixas. Avaliador é representante simulado da área, não se afirma que todos possuem cargo de gerente. Não foi coletado feedback de pessoa real ou da QSOFT.

## Índice demonstrativo

| Componente | Peso | Medida de risco |
|---|---:|---|
| Supervisão | 30% | Revisões não realizadas / revisões conhecidas |
| Qualidade | 20% | Tarefas com IA rejeitadas ou com retrabalho / tarefas com IA |
| Capacitação | 15% | Usuários observados sem registro de curso concluído até o mês / usuários observados |
| Governança | 15% | Logs de ferramentas bloqueadas/em avaliação / logs com decisão disponível na data do uso |
| Autonomia | 20% | Testes manuais reprovados / testes realizados no mês |

Cada componente é 100 × numerador/denominador, com mínimo de cinco observações, exceto autonomia (três testes). Só há score com pelo menos 20 tarefas com IA finalizadas e cobertura de pesos >=60%.

`score = média ponderada dos componentes disponíveis × (0,5 + 0,5 × percentil de intensidade)`

Intensidade usa requisições por usuário observado, comparadas entre unidades do MESMO escopo e mês. É uma medida relativa, sensível aos pares disponíveis. Sem sinais nos componentes, intensidade alta sozinha não produz score alto. Faixas: Baixo <35; Moderado >=35 e <55; Alto >=55 e <75; Crítico >=75. São hipóteses de demonstração, não metodologia validada ou probabilidade.

Os scores de departamento/equipe usam logs originais completos daquela unidade/mês. O escopo processo usa SOMENTE logs vinculados às tarefas amostradas. Não atribuímos logs sem tarefa a processos inventados. Os três escopos não são diretamente comparáveis nem somáveis.

Training utiliza somente conclusões até o fim do mês da base original, não notas/datas preenchidas artificialmente. Sem registro não significa que a pessoa nunca recebeu treinamento. Governança usa a decisão atual apenas depois de approval_date; sem histórico de mudanças não é possível reconstruir reversões de política. allowed_departments e eventos de segurança não entram nesta fórmula simplificada; podem aparecer em painéis próprios da base original. Avaliações não testadas e revisões desconhecidas não viram risco automaticamente.

As novas tabelas guardam snapshots calculados: novos logs não atualizam scores sozinhos. O gerador calcula esta entrega, mas não é serviço de produção. O backend deverá aplicar a fórmula versionada ao banco, gravar nova competência e executar as validações. Métricas futuras e histórico real de alterações de equipe/política devem ser implementados quando existirem dados.

Nesta versão os resultados calculados ficaram em Baixo, Moderado ou Dados insuficientes; não foram forçados casos Altos/Críticos para colorir o painel. Há 279 equipes, 2.356 vínculos, 5.868 snapshots, 29.340 componentes, 70 alertas, 53 ações e 25 feedbacks. Os snapshots abrangem unidades/meses com logs ou tarefas; ausência de linha em outros meses significa ausência de observação, nunca risco zero. Não há score individual nesta versão: o escopo é equipe, departamento e processo, conforme a hipótese. Um indivíduo não recebe rótulo pessoal de dependência.

## Tempo e validação da hipótese

Histórico de uso: junho/2025 a julho/2026. Cálculo retrospectivo: setembro/2026. Alertas, ações e feedbacks se passam em um cenário simulado iniciado em 18/09/2026, podendo avançar a outubro/2026. São exemplos futuros, não acontecimentos reais. Não se criou efeito causal de ações sobre meses anteriores.

Os mocks anteriores não são amostra uniforme de tarefas/colaboradores; dias com muito uso têm maior chance de seleção e tarefas manuais foram sorteadas. Não estimar adoção real, economia real de tempo ou jornada a partir deles. Preservamos essas limitações, sem alterar dados já feitos. As ações e opiniões simuladas testam o fluxo do produto, mas não demonstram que gestores reais o consideram útil.

## Integração e consultas

```sql
-- Heatmap por departamento e mês (não somar com equipes/processos).
SELECT department_id, period_start, final_score, risk_level, evidence_coverage
FROM qai_innovation_v2.innovation_dashboard_scores
WHERE scope_type='department';

-- Explicação de cada score.
SELECT score_id,component,numerator,denominator,weight,component_score,available
FROM qai_innovation_v2.innovation_score_components;

-- Alertas que resultaram em ações, sem multiplicar contagens por joins.
SELECT * FROM qai_innovation_v2.innovation_management_summary;

-- Relações observadas no mock para o grafo processo/ferramenta.
SELECT t.process_id,l.ai_tool_id,count(*) AS vinculos_amostrados
FROM qai_innovation_v2.innovation_tasks t
JOIN qai_innovation_v2.innovation_task_usage x ON x.task_id=t.task_id
JOIN public.ai_usage_logs l ON l.usage_id::text=x.usage_id
GROUP BY t.process_id,l.ai_tool_id;
```

As FKs internas são criadas. Vínculos à base original são validados pelo script 02 sem alterar estruturas de `public`, pois não tivemos acesso aos tipos, índices e constraints do seu PostgreSQL. Após conferir o schema real, o grupo poderá definir FKs externas compatíveis. Rodar novamente a validação após atualizar/importar a base. Autorizações e isolamento por empresa devem ser implementados no backend; este SQL não configura permissões de acesso.

## Verificação e reprodução

`validacao.json`: contagens, preservação das cinco tabelas, hashes, chaves internas, coerência das ações e recálculo independente dos scores. Não havia servidor PostgreSQL disponível aqui: o SQL foi preparado para esse banco, mas sua execução nativa ainda deve ser testada no ambiente do grupo. Não alegamos ter conectado ao banco de vocês.

Reprodução: `python complementar_postgresql.py synthetic_ai_usage_dataset.zip QAI_Control_Inovacao_Mock.zip pasta_nova`. Requer os dois ZIPs originais e este README como `README_postgresql.md` ao lado do gerador. Usa Python padrão, sem serviços externos. A saída deve não existir. O gerador restaura o SQL anterior em banco temporário, calcula o complemento e exporta o pacote; não modifica os ZIPs.
